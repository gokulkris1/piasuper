from pia.voice.loop import run_voice_loop

if __name__ == "__main__":
    print("📦 Skills loaded: reminders, web_search, summarizer")
    print("Pia is booting...")
    run_voice_loop()