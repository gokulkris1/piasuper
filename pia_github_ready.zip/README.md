# Pia — Personal Ambient AI Assistant

Pia is a modular, voice-first, presence-aware AI assistant powered by GPT-4o and local sensors.

## Features
- Voice input/output (STT + TTS)
- AI engine switching (GPT-4o, Claude)
- Skills: reminders, search, summarizer, notes
- Location and smart home integration

## Setup

1. Create `.env` using `.env.example`
2. Run:
```bash
pip install -r requirements.txt
python main.py
```